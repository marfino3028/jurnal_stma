@extends('frontEnd.layout')

@section('content')

<h3><font color="blueocean" >Ini Judul ya </font></h3>
<hr>
<div class="row">
<div class="col-md-4">

<h4><font color="blueocean"> View/ Open</font></h4><br>
<h5>Download</h5><br><br><br>

<h4><font color="blueocean"> Date</font></h4><br>
<h5>2019</h5><br><br><br>

<h4><font color="blueocean"> Author</font></h4><br>
<h5>Fino</h5><br><br><br>

<h4><font color="blueocean">Metadata</font></h4><br>
<a href=""> Show FUll Item Record</a>

</div>
<div class="col-md-8">
<p>isinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadninisinyainsinaisniadnin</p>
<br>

<h4><font color="blueocean">URL</font></h4><br>
<a href=""> linknya disini gan</a>

<h4><font color="blueocean">Collections</font></h4><br>
<a href=""> linknya disini gan</a>


</div>


@endsection