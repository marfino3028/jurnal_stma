@extends('frontEnd.layout')

@section('content')
<body class="js " style="  ">
<div id="wrapper">
    <!-- Content Section -->
    <div class="contents">

    <section id="content">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">

                    <article>
                                                    
                            <div class="post-image">
                                <div class="post-heading">
                                    <h1>
                                                                                Sample Lorem Ipsum Text
                                    </h1>
                                </div>
                                                                    <img src="http://smartfordesign.net/smartend/demo/uploads/topics/14888170311535.jpg" alt="Sample Lorem Ipsum Text" title="Sample Lorem Ipsum Text">
                                                            </div>
                        <div dir="ltr"><div dir="ltr" style="font-size: 13.92px; text-align: justify;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed at ante. Mauris eleifend, quam a vulputate dictum, massa quam dapibus leo, eget vulputate orci purus ut lorem. In fringilla mi in ligula. Pellentesque aliquam quam vel dolor. Nunc adipiscing. Sed quam odio, tempus ac, aliquam molestie, varius ac, tellus. Vestibulum ut nulla aliquam risus rutrum interdum. Pellentesque lorem. Curabitur sit amet erat quis risus feugiat viverra. Pellentesque augue justo, sagittis et, lacinia at, venenatis non, arcu. Nunc nec libero. In cursus dictum risus. Etiam tristique nisl a nulla. Ut a orci. Curabitur dolor nunc, egestas at, accumsan at, malesuada nec, magna.</div><div dir="ltr" style="font-size: 13.92px; text-align: justify;">Nulla facilisi. Nunc volutpat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Ut sit amet orci vel mauris blandit vehicula. Nullam quis enim. Integer dignissim viverra velit. Curabitur in odio. In hac habitasse platea dictumst. Ut consequat, tellus eu volutpat varius, justo orci elementum dolor, sed imperdiet nulla tellus ut diam. Vestibulum ipsum ante, malesuada quis, tempus ac, placerat sit amet, elit.</div><div dir="ltr" style="font-size: 13.92px; text-align: justify;">Sed eget turpis a pede tempor malesuada. Vivamus quis mi at leo pulvinar hendrerit. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Pellentesque aliquet lacus vitae pede. Nullam mollis dolor ac nisi. Phasellus sit amet urna. Praesent pellentesque sapien sed lacus. Donec lacinia odio in odio. In sit amet elit. Maecenas gravida interdum urna. Integer pretium, arcu vitae imperdiet facilisis, elit tellus tempor nisi, vel feugiat ante velit sit amet mauris. Vivamus arcu. Integer pharetra magna ac lacus. Aliquam vitae sapien in nibh vehicula auctor. Suspendisse leo mauris, pulvinar sed, tempor et, consequat ac, lacus. Proin velit. Nulla semper lobortis mauris. Duis urna erat, ornare et, imperdiet eu, suscipit sit amet, massa. Nulla nulla nisi, pellentesque at, egestas quis, fringilla eu, diam.</div><div dir="ltr" style="font-size: 13.92px; text-align: justify;">Donec semper, sem nec tristique tempus, justo neque commodo nisl, ut gravida sem tellus suscipit nunc. Aliquam erat volutpat. Ut tincidunt pretium elit. Aliquam pulvinar. Nulla cursus. Suspendisse potenti. Etiam condimentum hendrerit felis. Duis iaculis aliquam enim. Donec dignissim augue vitae orci. Curabitur luctus felis a metus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In varius neque at enim. Suspendisse massa nulla, viverra in, bibendum vitae, tempor quis, lorem.</div><div dir="ltr" style="font-size: 13.92px; text-align: justify;">Donec dapibus orci sit amet elit. Maecenas rutrum ultrices lectus. Aliquam suscipit, lacus a iaculis adipiscing, eros orci pellentesque nisl, non pharetra dolor urna nec dolor. Integer cursus dolor vel magna. Integer ultrices feugiat sem. Proin nec nibh. Duis eu dui quis nunc sagittis lobortis. Fusce pharetra, enim ut sodales luctus, lectus arcu rhoncus purus, in fringilla augue elit vel lacus. In hac habitasse platea dictumst. Aliquam erat volutpat. Fusce iaculis elit id tellus. Ut accumsan malesuada turpis. Suspendisse potenti. Vestibulum lacus augue, lobortis mattis, laoreet in, varius at, nisi. Nunc gravida. Phasellus faucibus. In hac habitasse platea dictumst. Integer tempor lacus eget lectus. Praesent fringilla augue fringilla dui.</div><div dir="ltr" style="font-size: 13.92px; text-align: justify;">&nbsp;</div><div><br></div></div>

                        <div class="bottom-article">
                            <ul class="meta-post">
                                                                    <li><i class="fa fa-calendar"></i> <a>2017-03-06</a></li>
                                                                <li><i class="fa fa-eye"></i> <a>Visits
                                        : 3</a></li>
                                                                    <li><i class="fa fa-comments"></i><a href="#comments">Comments
                                            : 0 </a>
                                    </li>
                                                            </ul>
                            <div class="pull-right">
                                Share :
                                <ul class="social-network share">
                                    <li><a href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fsmartfordesign.net%2Fsmartend%2Fdemo%2Fblog%2Ftopic%2F15" class="facebook" data-placement="top" title="" target="_blank" data-original-title="Facebook"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="https://twitter.com/intent/tweet?text=Sample Lorem Ipsum Text&amp;url=http%3A%2F%2Fsmartfordesign.net%2Fsmartend%2Fdemo%2Fblog%2Ftopic%2F15" class="twitter" data-placement="top" title="" target="_blank" data-original-title="Twitter"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="https://plus.google.com/share?url=http%3A%2F%2Fsmartfordesign.net%2Fsmartend%2Fdemo%2Fblog%2Ftopic%2F15" class="google" data-placement="top" title="" target="_blank" data-original-title="Google+"><i class="fa fa-google-plus"></i></a></li>
                                    <li><a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=http%3A%2F%2Fsmartfordesign.net%2Fsmartend%2Fdemo%2Fblog%2Ftopic%2F15&amp;title=Sample Lorem Ipsum Text" class="linkedin" data-placement="top" title="" target="_blank" data-original-title="linkedin"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="http://www.tumblr.com/share/link?url=http%3A%2F%2Fsmartfordesign.net%2Fsmartend%2Fdemo%2Fblog%2Ftopic%2F15" class="pintrest" data-placement="top" title="" target="_blank" data-original-title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
                                </ul>
                            </div>
                        </div>

                        

                                                    <div id="comments">
                                
                                <div class="row">
                                    <div class="col-lg-12">
                                        <br>
                                        <h4><i class="fa fa-plus"></i> Add New Comment</h4>
                                        <div class="bottom-article newcomment">
                                            <div id="sendmessage"><i class="fa fa-check-circle"></i>
                                                &nbsp;Your Comment has been sent successfully. Thank you! &nbsp; <a href="http://smartfordesign.net/smartend/demo/blog/topic/15"><i class="fa fa-refresh"></i> Refresh
                                                </a>
                                            </div>
                                            <div id="errormessage">Error: Please try again</div>

                                            <form method="POST" action="http://smartfordesign.net/smartend/demo" accept-charset="UTF-8" class="commentForm"><input name="_token" type="hidden" value="mW4qwSCYxdZ2AKLd42xc8V5U2vPc4bgOHW75wN3Q">
                                            <div class="form-group">
                                                <input placeholder="Your Name" class="form-control" id="comment_name" data-msg="Please enter your name" data-rule="minlen:4" name="comment_name" type="text">
                                                <div class="alert alert-warning validation"></div>
                                            </div>
                                            <div class="form-group">
                                                <input placeholder="Your Email" class="form-control" id="comment_email" data-msg="Please enter your email address" data-rule="email" name="comment_email" type="email">
                                                <div class="validation"></div>
                                            </div>
                                            <div class="form-group">
                                                <textarea placeholder="Comment" class="form-control" id="comment_message" rows="5" data-msg="Please enter your comment" data-rule="required" name="comment_message" cols="50"></textarea>
                                                <div class="validation"></div>
                                            </div>

                                                                                            <div class="form-group">
                                                    <script type="text/javascript" async="" src="https://www.gstatic.com/recaptcha/releases/yXSLJBpiFoTYkexaPhFknpU7/recaptcha__en.js" crossorigin="anonymous" integrity="sha384-fEtnLkXMpwhEXyV802C09EtQCfEekHEGh4Dzy/7Sn0xtxDbO9+NbG9N1yHY3nOiY"></script><script src="https://www.google.com/recaptcha/api.js?hl=en" async="" defer=""></script>

                                                    <div data-sitekey="6LcriRYUAAAAAGEzog0hxEJqaje1bXluS8T7hJQ7" class="g-recaptcha"><div style="width: 304px; height: 78px;"><div><iframe src="https://www.google.com/recaptcha/api2/anchor?ar=1&amp;k=6LcriRYUAAAAAGEzog0hxEJqaje1bXluS8T7hJQ7&amp;co=aHR0cDovL3NtYXJ0Zm9yZGVzaWduLm5ldDo4MA..&amp;hl=en&amp;v=yXSLJBpiFoTYkexaPhFknpU7&amp;size=normal&amp;cb=o9tq0oyccu79" width="304" height="78" role="presentation" name="a-uo1f3vu66px5" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea></div><iframe style="display: none;"></iframe></div>
                                                </div>
                                                                                        <div>
                                                <input type="hidden" name="topic_id" value="15">
                                                <button type="submit" class="btn btn-theme">Send Comment</button>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                        

                                                                            
                    </article>
                </div>
                                    <div class="col-lg-4">
    <aside class="right-sidebar">
        <div class="widget">
            <form method="POST" action="http://smartfordesign.net/smartend/demo/search" accept-charset="UTF-8" class="form-search"><input name="_token" type="hidden" value="mW4qwSCYxdZ2AKLd42xc8V5U2vPc4bgOHW75wN3Q">
            <div class="input-group input-group-sm">
                <input placeholder="Search for..." class="form-control" id="search_word" required="" name="search_word" type="text">
                <span class="input-group-btn">
                    <button type="submit" class="btn btn-theme"><i class="fa fa-search"></i></button>
                </span>
            </div>

            </form>
        </div>

                <div class="widget">
                <h5 class="widgetheading">Categories</h5>
                <ul class="cat">
                <li>
                <i class="fa fa-desktop"></i> &nbsp;
                <a class="active" href="http://smartfordesign.net/smartend/demo/blog/1">Web Design</a><span class="pull-right">(4)</span></li>
                        
                <li>    <i class="fa fa-apple"></i> &nbsp;
                <a href="http://smartfordesign.net/smartend/demo/blog/2">Mobile Applications</a><span class="pull-right">(3)</span></li>
                        
                <li>    <i class="fa fa-motorcycle"></i> &nbsp;
                <a href="http://smartfordesign.net/smartend/demo/blog/3">Motion Draws</a><span class="pull-right">(3)</span></li>
                        
                <li>    <i class="fa fa-html5"></i> &nbsp;
                <a href="http://smartfordesign.net/smartend/demo/blog/4">Web Development</a><span class="pull-right">(1)</span></li>
                        
                <li>    <i class="fa fa-connectdevelop"></i> &nbsp;
                <a href="http://smartfordesign.net/smartend/demo/blog/5">Publications Design</a><span class="pull-right">(1)</span></li>
                        
                <li>    <i class="fa fa-line-chart"></i> &nbsp;
                <a href="http://smartfordesign.net/smartend/demo/blog/6">Search Engines Optmization</a><span class="pull-right">(2)</span></li>
                        
                <li>    <i class="fa fa-modx"></i> &nbsp;
                <a href="http://smartfordesign.net/smartend/demo/blog/7">3d Design</a><span class="pull-right">(0)</span></li>            </ul>
                </div>
                                        <div class="widget">
                <h5 class="widgetheading">Most Viewed</h5>
                <ul class="recent">
                                                                    <li>
                            <div class="row">
                                <div class="col-lg-12">
                                    <a href="http://smartfordesign.net/smartend/demo/blog/topic/21">
                                                                                    <img src="http://smartfordesign.net/smartend/demo/uploads/topics/14888171106415.jpg" class="pull-left" alt="Sample Lorem Ipsum Text, sed imperdiet nulla tellus ut diam.">
                                                                            </a>
                                    <h6>
                                        <a href="http://smartfordesign.net/smartend/demo/blog/topic/21">Sample Lorem Ipsum Text, sed imperdiet nulla tellus ut diam.</a>
                                    </h6>
                                </div>
                            </div>
                        </li>
                                                                    <li>
                            <div class="row">
                                <div class="col-lg-12">
                                    <a href="http://smartfordesign.net/smartend/demo/blog/topic/15">
                                                                                    <img src="http://smartfordesign.net/smartend/demo/uploads/topics/14888170311535.jpg" class="pull-left" alt="Sample Lorem Ipsum Text">
                                                                            </a>
                                    <h6>
                                        <a href="http://smartfordesign.net/smartend/demo/blog/topic/15">Sample Lorem Ipsum Text</a>
                                    </h6>
                                </div>
                            </div>
                        </li>
                                                                    <li>
                            <div class="row">
                                <div class="col-lg-12">
                                    <a href="http://smartfordesign.net/smartend/demo/blog/topic/16">
                                                                                    <img src="http://smartfordesign.net/smartend/demo/uploads/topics/14888170546118.jpg" class="pull-left" alt="Sample Lorem Ipsum Text">
                                                                            </a>
                                    <h6>
                                        <a href="http://smartfordesign.net/smartend/demo/blog/topic/16">Sample Lorem Ipsum Text</a>
                                    </h6>
                                </div>
                            </div>
                        </li>
                        </ul>
            </div>
        
                <div class="widget">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Slider -->
                                                                                                                                                    
                        <div class="text-center">
                                                            <div>
                                                                            <a href="#">
                                                                                                                                        <img src="http://smartfordesign.net/smartend/demo/uploads/banners/14888184559632.png" alt="Side banner sample">
                    </a>
                                                                        
                                </div>
                                                    </div>
                                    <!-- end slider -->
                </div>
            </div>
        </div>
    </aside>
    </div>
    </div>
        </div>
    </section>

    </div>
    <!-- end of Content Section -->

</div>
<a href="#" title="to Top" class="scrollup" style="display: inline;"><i class="fa fa-angle-up active"></i></a>

<script type="text/javascript">
    var page_dir = "ltr";
</script>
<script src="http://smartfordesign.net/smartend/demo/frontEnd/js/jquery.js"></script>
<script src="http://smartfordesign.net/smartend/demo/frontEnd/js/jquery.easing.1.3.js"></script>
<script src="http://smartfordesign.net/smartend/demo/frontEnd/js/bootstrap.min.js"></script>
<script src="http://smartfordesign.net/smartend/demo/frontEnd/js/jquery.fancybox.pack.js"></script>
<script src="http://smartfordesign.net/smartend/demo/frontEnd/js/jquery.fancybox-media.js"></script>
<script src="http://smartfordesign.net/smartend/demo/frontEnd/js/google-code-prettify/prettify.js"></script>
<script src="http://smartfordesign.net/smartend/demo/frontEnd/js/portfolio/jquery.quicksand.js"></script>
<script src="http://smartfordesign.net/smartend/demo/frontEnd/js/portfolio/setting.js"></script>
<script src="http://smartfordesign.net/smartend/demo/frontEnd/js/jquery.flexslider.js"></script>
<script src="http://smartfordesign.net/smartend/demo/frontEnd/js/animate.js"></script>
<script src="http://smartfordesign.net/smartend/demo/frontEnd/js/custom.js"></script>
<script src="http://smartfordesign.net/smartend/demo/frontEnd/js/owl-carousel/owl.carousel.js"></script>


    <script type="text/javascript">
        jQuery(document).ready(function ($) {
            "use strict";

            //Subscribe
            $('form.subscribeForm').submit(function () {

                var f = $(this).find('.form-group'),
                    ferror = false,
                    emailExp = /^[^\s()<>@,;:\/]+@\w[\w\.-]+\.[a-z]{2,}$/i;

                f.children('input').each(function () { // run all inputs

                    var i = $(this); // current input
                    var rule = i.attr('data-rule');

                    if (rule !== undefined) {
                        var ierror = false; // error flag for current input
                        var pos = rule.indexOf(':', 0);
                        if (pos >= 0) {
                            var exp = rule.substr(pos + 1, rule.length);
                            rule = rule.substr(0, pos);
                        } else {
                            rule = rule.substr(pos + 1, rule.length);
                        }

                        switch (rule) {
                            case 'required':
                                if (i.val() === '') {
                                    ferror = ierror = true;
                                }
                                break;

                            case 'minlen':
                                if (i.val().length < parseInt(exp)) {
                                    ferror = ierror = true;
                                }
                                break;

                            case 'email':
                                if (!emailExp.test(i.val())) {
                                    ferror = ierror = true;
                                }
                                break;

                            case 'checked':
                                if (!i.attr('checked')) {
                                    ferror = ierror = true;
                                }
                                break;

                            case 'regexp':
                                exp = new RegExp(exp);
                                if (!exp.test(i.val())) {
                                    ferror = ierror = true;
                                }
                                break;
                        }
                        i.next('.validation').html('<i class=\"fa fa-info\"></i> &nbsp;' + ( ierror ? (i.attr('data-msg') !== undefined ? i.attr('data-msg') : 'wrong Input') : '' )).show();
                        !ierror ? i.next('.validation').hide() : i.next('.validation').show();
                    }
                });
                if (ferror) return false;
                else var str = $(this).serialize();
                $.ajax({
                    type: "POST",
                    url: "http://smartfordesign.net/smartend/demo/subscribe",
                    data: str,
                    success: function (msg) {
                        if (msg == 'OK') {
                            $("#subscribesendmessage").addClass("show");
                            $("#subscribeerrormessage").removeClass("show");
                            $("#subscribe_name").val('');
                            $("#subscribe_email").val('');
                        }
                        else {
                            $("#subscribesendmessage").removeClass("show");
                            $("#subscribeerrormessage").addClass("show");
                            $('#subscribeerrormessage').html(msg);
                        }

                    }
                });
                return false;
            });

        });
    </script>





        <script type="text/javascript">

        jQuery(document).ready(function ($) {
            "use strict";

                        //Comment
            $('form.commentForm').submit(function () {

                var f = $(this).find('.form-group'),
                    ferror = false,
                    emailExp = /^[^\s()<>@,;:\/]+@\w[\w\.-]+\.[a-z]{2,}$/i;

                f.children('input').each(function () { // run all inputs

                    var i = $(this); // current input
                    var rule = i.attr('data-rule');

                    if (rule !== undefined) {
                        var ierror = false; // error flag for current input
                        var pos = rule.indexOf(':', 0);
                        if (pos >= 0) {
                            var exp = rule.substr(pos + 1, rule.length);
                            rule = rule.substr(0, pos);
                        } else {
                            rule = rule.substr(pos + 1, rule.length);
                        }

                        switch (rule) {
                            case 'required':
                                if (i.val() === '') {
                                    ferror = ierror = true;
                                }
                                break;

                            case 'minlen':
                                if (i.val().length < parseInt(exp)) {
                                    ferror = ierror = true;
                                }
                                break;

                            case 'email':
                                if (!emailExp.test(i.val())) {
                                    ferror = ierror = true;
                                }
                                break;

                            case 'checked':
                                if (!i.attr('checked')) {
                                    ferror = ierror = true;
                                }
                                break;

                            case 'regexp':
                                exp = new RegExp(exp);
                                if (!exp.test(i.val())) {
                                    ferror = ierror = true;
                                }
                                break;
                        }
                        i.next('.validation').html('<i class=\"fa fa-info\"></i> &nbsp;' + ( ierror ? (i.attr('data-msg') !== undefined ? i.attr('data-msg') : 'wrong Input') : '' )).show();
                        !ierror ? i.next('.validation').hide() : i.next('.validation').show();
                    }
                });
                f.children('textarea').each(function () { // run all inputs

                    var i = $(this); // current input
                    var rule = i.attr('data-rule');

                    if (rule !== undefined) {
                        var ierror = false; // error flag for current input
                        var pos = rule.indexOf(':', 0);
                        if (pos >= 0) {
                            var exp = rule.substr(pos + 1, rule.length);
                            rule = rule.substr(0, pos);
                        } else {
                            rule = rule.substr(pos + 1, rule.length);
                        }

                        switch (rule) {
                            case 'required':
                                if (i.val() === '') {
                                    ferror = ierror = true;
                                }
                                break;

                            case 'minlen':
                                if (i.val().length < parseInt(exp)) {
                                    ferror = ierror = true;
                                }
                                break;
                        }
                        i.next('.validation').html('<i class=\"fa fa-info\"></i> &nbsp;' + ( ierror ? (i.attr('data-msg') != undefined ? i.attr('data-msg') : 'wrong Input') : '' )).show();
                        !ierror ? i.next('.validation').hide() : i.next('.validation').show();
                    }
                });
                if (ferror) return false;
                else var str = $(this).serialize();
                $.ajax({
                    type: "POST",
                    url: "http://smartfordesign.net/smartend/demo/comment",
                    data: str,
                    success: function (msg) {
                        if (msg == 'OK') {
                            $("#sendmessage").addClass("show");
                            $("#errormessage").removeClass("show");
                            $("#comment_name").val('');
                            $("#comment_email").val('');
                            $("#comment_message").val('');
                        }
                        else {
                            $("#sendmessage").removeClass("show");
                            $("#errormessage").addClass("show");
                            $('#errormessage').html(msg);
                        }

                    }
                });
                return false;
            });
            
                    });
    </script>

@endsection