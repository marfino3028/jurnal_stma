<!-- Key Field -->
<div class="form-group">
   
    <p>
        {!! Form::label('key', 'Key:') !!}{{ $metadata->key }}</p>
</div>

<!-- Value Field -->
<div class="form-group">
    <p>
    {!! Form::label('value', 'Value:') !!}
    {{ $metadata->value }}</p>
</div>

