# Web Master Aplikasi

Fitur
- CRUD Roles
- CRUD User
- CRUD Kategori - Katalog
- CRUD Metadata
- Update profile

## Cara Menggunakan
- clone dari repository
- composer install
- setting .env
- artisan migrate
- artisan db:seed

## Login
- administrator : admin123
- dosen : dosen
- mahasiswa : mahasiswa
- user : user

&copy; @dwijonarko 2020
